package com.zhangjikai.pojo;

/**
 * Created by zhangjk on 2016/1/16.
 */
public class FileMeta {
    private String name;
    private String url;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
