package com.zhangjikai.pojo;

import java.util.List;

/**
 * Created by zhangjk on 2016/1/16.
 */
public class FileMsg {
    private List<FileMeta> files;

    public List<FileMeta> getFiles() {
        return files;
    }

    public void setFiles(List<FileMeta> files) {
        this.files = files;
    }
}
