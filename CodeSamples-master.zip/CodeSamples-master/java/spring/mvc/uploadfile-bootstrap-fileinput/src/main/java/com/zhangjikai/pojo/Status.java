package com.zhangjikai.pojo;

/**
 * Created by zhangjk on 2016/1/16.
 */
public enum Status {
    SUCCESS  , ERROR
}
